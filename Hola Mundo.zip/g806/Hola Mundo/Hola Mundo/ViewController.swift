//
//  ViewController.swift
//  Hola Mundo
//
//  Created by leyf on 6/9/18.
//  Copyright © 2018 UPM. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    @IBOutlet weak var msgLabel: UILabel!
    
    @IBOutlet weak var buttonMundo: UIButton!
    @IBOutlet weak var buttonHola: UIButton!
    @IBOutlet weak var buttonSol: UIButton!
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        buttonSol.layer.cornerRadius = 20
        buttonHola.layer.cornerRadius = 20
        buttonMundo.layer.cornerRadius = 20
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func updateSol(_ sender: UIButton) {
        
        let center = CLLocationCoordinate2D(latitude: 40.417078, longitude: -3.703067)
        let span = MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004 )
        let reg = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(reg, animated: true)
    }
    
    
    @IBAction func updateHola(_ sender: UIButton) {
        msgLabel.text = "Hola"
        msgLabel.alpha = 0.5
        mapView.mapType = MKMapType.hybrid
        let center = CLLocationCoordinate2D(latitude: 40.689401, longitude: -74.044215)
        let span = MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004 )
        let reg = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(reg, animated: true)
        
    }
    
    @IBAction func updateMundo(_ sender: UIButton) {
        msgLabel.text = "Mundo"
        mapView.mapType = MKMapType.satellite
        let center = CLLocationCoordinate2D(latitude:40.452445, longitude: -3.726162)
        let span = MKCoordinateSpan(latitudeDelta: 0.004, longitudeDelta: 0.004 )
        let reg = MKCoordinateRegion(center: center, span: span)
        mapView.setRegion(reg, animated: true)
    }
    
    @IBAction func updateAlpha(_ sender: UISlider) {
        msgLabel.alpha = CGFloat(sender.value)
    }
    
}

